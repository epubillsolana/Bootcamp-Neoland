# Guía Práctica de Laboratorio: Análisis de Datos en Google Sheets y Excel

**Duración Total:** 24 Horas  
**Estructura:** 3 Módulos de 8 Horas  
**Archivos de Trabajo Requeridos:**

* `Dataset_Ventas_Regionales` (Transacciones)  
* `Maestro_Productos_Precios` (Catálogo e información técnica)

---

## Módulo 1: Introducción Avanzada, Depuración y Búsquedas Dinámicas (8 Horas)

### Objetivo del Módulo

Desarrollar habilidades prácticas para identificar inconsistencias en bases de datos crudas, aplicar técnicas estandarizadas de limpieza con funciones de texto, manejar referencias de celdas para automatización y realizar cruces de bases de datos mediante funciones de búsqueda modernas.

---

### Ejercicio 1.1: Auditoría y Normalización de Texto (2 horas)

**Escenario:** La base de datos `Dataset_Ventas_Regionales` proviene de un formulario de carga manual sin validación previa. Existen espacios invisibles, inconsistencias en el uso de mayúsculas y caracteres no deseados en las columnas `Sucursal` y `Vendedor`.

1. **Depuración de Espacios Ocultos:**

   * Agrega una columna a la derecha de `Sucursal` y nómbrala `Sucursal_Limpia`.  
   * En la celda `C2` de la nueva columna, aplica la función `ESPACIOS` (en inglés `TRIM`) para eliminar espacios al inicio, al final o dobles espacios en el texto.  
   * *Fórmula a utilizar:* `=ESPACIOS(C2)`  
   * Arrastra o aplica el autorrelleno para toda la columna.  
2. **Estandarización de Formato Nombre Propio:**

   * Agrega una columna a la derecha de `Vendedor` y nómbrala `Vendedor_Limpio`.  
   * En la celda `E2`, combina las funciones `NOMPROPIO` (en inglés `PROPER`) y `ESPACIOS` para convertir cadenas como `"juan perez"` o `" MARIA GOMEZ "` al formato estandarizado `"Juan Perez"` y `"Maria Gomez"`.  
   * *Fórmula a utilizar:* `=NOMPROPIO(ESPACIOS(D2))`  
3. **Validación de Identificadores (Funciones `LARGO` e `IZQUIERDA`):**

   * En la columna `ID_Transaccion`, verifica que todos los códigos tengan exactamente 8 caracteres.  
   * En una nueva columna llamada `Control_ID`, utiliza la función `LARGO` (`LEN`) para contar los caracteres.  
   * *Fórmula:* `=LARGO(A2)`  
   * Extrae el prefijo de 2 letras del ID utilizando la función `IZQUIERDA` (`LEFT`) en la columna `Codigo_Region`:  
   * *Fórmula:* `=IZQUIERDA(A2; 2)`

---

### Ejercicio 1.2: Cruzado de Bases de Datos con `BUSCARX` y Manejo de Errores (3 horas)

**Escenario:** Se requiere enriquecer la tabla de ventas incorporando los datos del proveedor, el costo base y la categoría oficial desde la hoja `Maestro_Productos_Precios`.

1. **Cruce de Proveedores mediante `BUSCARX`:**

   * En la tabla principal de ventas, inserta la columna `Proveedor`.  
   * Aplica la función `BUSCARX` (`XLOOKUP`) para buscar el código o nombre del producto en el maestro y retornar el proveedor correspondiente.  
   * *Fórmula (Google Sheets / Excel):*  
     `=BUSCARX(F2; Maestro_Productos_Precios!$A:$A; Maestro_Productos_Precios!$C:$C; "No Encontrado")`  
   * *Nota Pedagógica:* Asegúrate de explicar el uso de fijación de rangos con el signo `$` (Referencias Absolutas).  
2. **Alternativa Clásica con `INDICE` \+ `COINCIDIR`:**

   * En la columna `Categoria_Oficial`, realiza la búsqueda utilizando la combinación `INDICE` \+ `COINCIDIR` (`INDEX` \+ `MATCH`) para afianzar compatibilidad en versiones antiguas de Excel.  
   * *Fórmula:*  
     `=INDICE(Maestro_Productos_Precios!$B:$B; COINCIDIR(F2; Maestro_Productos_Precios!$A:$A; 0))`  
3. **Manejo de Excepciones con `SI.ERROR`:**

   * Envuelve las fórmulas de búsqueda anteriores dentro de la función `SI.ERROR` (`IFERROR`) para evitar que la hoja muestre `#N/D` o `#N/A` cuando un producto no figure en el catálogo.  
   * *Fórmula:*  
     `=SI.ERROR(BUSCARX(...); "Producto No Sincronizado")`

---

### Ejercicio 1.3: Lógica Condicional y Agregaciones Multicriterio (3 horas)

**Escenario:** La gerencia requiere métricas rápidas de consolidación sin alterar la estructura tabular original.

1. **Cálculo de Unidades y Facturación Condicional:**

   * Crea una pestaña llamada `Reporte_Consolidado_M1`.  
   * Diseña una tabla resumen con las sucursales en las filas: `"Corrientes"`, `"Resistencia"`, `"Posadas"`, `"Formosa"`.  
   * En la columna `Total_Ventas`, calcula la facturación total por sucursal usando `SUMAR.SI.CONJUNTO` (`SUMIFS`).  
   * *Fórmula:*  
     `=SUMAR.SI.CONJUNTO(Ventas!$H:$H; Ventas!$C:$C; "Corrientes")`  
2. **Evaluación Multicriterio con Comisiones:**

   * Regresa a la tabla de ventas y crea la columna `Comision_Estado`.  
   * Aplica una regla condicional compuesta: Si el `Total_Venta` es superior a \$50.000 Y la sucursal es `"Corrientes"`, la comisión será de $5\%$. Si no, será de $2\%$.  
   * *Fórmula:*  
     `=SI(BUSCARV(E2; Reporte_Consolidado_M1!$A$2:$B$4; 2; FALSO) > 50000; J2 * 0,05; J2 * 0,02)`

---

## Módulo 2: Tablas Dinámicas y Análisis Exploratorio de Datos (8 Horas)

### Objetivo del Módulo

Capacitar al estudiante en la construcción, manipulación y optimización de tablas dinámicas (Pivot Tables) para realizar análisis exploratorios, agrupamientos temporales y métricas calculadas complejas.

---

### Ejercicio 2.1: Construcción de Matrices de Resumen Multidimensional (2.5 horas)

1. **Generación de la Primera Tabla Dinámica:**

   * Selecciona todo el rango de datos limpios del Módulo 1\.  
   * Ve a `Insertar` $\rightarrow$ `Tabla Dinámica` y ubícala en una nueva hoja llamada `TD_Resumen_Ejecutivo`.  
2. **Configuración de Campos:**

   * **Filas:** `Sucursal_Limpia`  
   * **Columnas:** `Categoria`  
   * **Valores:** Suma de `Total_Venta`  
   * **Filtros Generales:** `Anio` (Año)  
3. **Formato Visual y Porcentajes Relativos:**

   * Modifica la configuración del campo de valor para que los montos se muestren como **`% del total de la fila`**.  
   * Responde a la pregunta: *¿Cuál es la categoría dominante de ventas en la sucursal Posadas?*

---

### Ejercicio 2.2: Agrupamientos de Fechas y Análisis de Tendencias (2.5 horas)

1. **Agrupamiento por Períodos Temporales:**

   * Crea una nueva Tabla Dinámica en la hoja `TD_Estacionalidad`.  
   * Coloca el campo `Fecha` en **Filas**.  
   * Haz clic derecho sobre cualquier fecha de la tabla dinámica y selecciona **Agrupar por intervalo de tiempo** $\rightarrow$ Selecciona **Año** y **Mes**.  
2. **Análisis de Dispersión y Promedios:**

   * Arrastra el campo `Total_Venta` al área de **Valores** dos veces:  
     * La primera configuración debe mostrar la **Suma**.  
     * La segunda configuración debe mostrar el **Promedio** por transacción.  
   * Añade el campo `Cantidad` como **Recuento** para medir el volumen absoluto de operaciones.

---

### Ejercicio 2.3: Campos Calculados y Segmentadores Interactivos (3 horas)

1. **Creación de Campo Calculado de Rentabilidad:**

   * En la barra de herramientas de la Tabla Dinámica, navega a `Campos, elementos y conjuntos` $\rightarrow$ `Campo calculado`.  
   * Nombre del campo: `Ganancia_Neta`  
   * \= Precio\_unitario \* Cantidad  
   * *Fórmula del campo:* `='Total de Ventas'-'Total de Costo'`  
2. **Creación de Campo Calculado de Margen %:**

   * Crea un segundo campo calculado llamado `Margen_Porcentual`.  
   * *Fórmula del campo:* `= ((Precio_Unitario - Costo_Unitario) / Precio_Unitario)`  
   * Aplica formato de porcentaje con dos decimales a toda la columna resultante.  
3. **Conexión de Segmentadores de Datos (Slicers):**

   * Inserta un **Segmentador de Datos** (`Slicer`) para el campo `Vendedor_Limpio`.  
   * Inserta un segundo **Segmentador de Datos** para la variable `Canal_Venta` (Online vs. Presencial).  
   * Comprueba cómo se actualizan dinámicamente las cifras al filtrar por distintos vendedores.

---

## Módulo 3: Visualización de Datos, Formato Condicional y Dashboards (8 Horas)

### Objetivo del Módulo

Diseñar tableros de control ejecutivos integrando gráficos dinámicos, técnicas de limpia visual, formato condicional interactivo y KPI Cards para proyectar información clara a tomadores de decisión.

---

### Ejercicio 3.1: Diseño de Gráficos Especializados (2.5 horas)

1. **Gráfico de Evolución Temporal (Líneas con Marcadores):**

   * Conecta un gráfico de líneas a la tabla dinámica de ventas mensuales.  
   * Elimina el fondo, oculta las líneas de cuadrícula secundarias y asigna una línea de tendencia para evaluar la proyección del negocio.  
2. **Gráfico de Barras Horizontales (Comparación Top Performers):**

   * Genera un gráfico de barras horizontales basado en los 10 productos más vendidos.  
   * Ordena los datos de mayor a menor para facilitar la lectura visual rápida.  
   * Ajusta el ancho del rango (ancho de serie) al $50\%$ para mejorar la proporción estética de las barras.  
3. **Gráfico Combinado (Ingresos vs. Margen %):**

   * Crea un gráfico combinado donde la facturación en pesos se represente en **Columnas (Eje Principal Izquierdo)** y el Margen % en una **Línea (Eje Secundario Derecho)**.

---

### Ejercicio 3.2: Reglas de Formato Condicional Avanzado (2.5 horas)

1. **Semáforo de Rendimiento:**

   * En la tabla de resumen de sucursales, selecciona las celdas de ingresos.  
   * Aplica una regla de formato condicional con la escala de colores (Verde \- Amarillo \- Rojo) basada en percentiles ($10\%$, $50\%$, $90\%$).  
2. **Barras de Datos Integradas:**

   * Aplica **Barras de Datos** (Data Bars) de color azul suave sobre la columna de volúmenes de unidades vendidas.  
   * Configura la regla para que muestre únicamente la barra visual, ocultando los valores numéricos si es necesario para un reporte limpio.  
3. **Resaltado Dinámico de Metas:**

   * Crea una regla basada en fórmulas en la tabla principal: Resalta en rojo claro toda la fila donde la transacción haya registrado un descuento mayor al $20\%$ Y una ganancia negativa.  
   * *Fórmula condicional:* `=Y($I2>0.2; $J2<0)`

---

### Ejercicio 3.3: Ensamblado y Publicación del Dashboard Ejecutivo (3 horas)

1. **Preparación del Lienzo del Tablero:**

   * Crea una pestaña nueva llamada `Dashboard_Ejecutivo`.  
   * Inactiva las líneas de cuadrícula (`Ver` $\rightarrow$ `Mostrar` $\rightarrow$ Desmarcar `Líneas de cuadrícula`).  
   * Aplica un color de fondo gris neutro muy claro (`#F8F9FA` o similar) para generar contraste profesional.  
2. **Construcción de Tarjetas KPI (KPI Cards):**

   * En la parte superior del lienzo, reserva 3 bloques rectangulares con bordes suaves.  
   * Vincula cada tarjeta directamente con fórmulas a las celdas resumen:  
     * **KPI 1:** Facturación Total General.  
     * **KPI 2:** Ticket Promedio por Operación.  
     * **KPI 3:** Margen Promedio General.  
3. **Distribución y Alineación:**

   * Coloca el gráfico de línea (Tendencia) en el bloque superior izquierdo.  
   * Ubica el gráfico combinado (Facturación vs. Margen) en la zona derecha.  
   * Agrupa los **Segmentadores de Datos (Slicers)** en un panel lateral o superior para simular una aplicación web interactiva.  
   * Prueba la interacción: Selecciona una sucursal en el segmentador y verifica que todos los gráficos y KPIs se reconfiguren en tiempo real.

&nbsp;